from union2 import *
import argparse
parser = argparse.ArgumentParser(description='The input file.')
parser.add_argument('filename')

args = parser.parse_args()
#print(args)
file_name = args.filename

#t0 = time.time()
drivers, pins, dict, x, y, coord_dict = read_drivers_pins(file_name)


n = len(x)
points = [0]*n
for i in range(n):
    points[i] = (x[i], y[i])

array_clusters, final_centers = kclustering(drivers, pins, points)


#Llista de structs de cluster
clusters: Clusters = []
for i in range(len(array_clusters)):
    points_cluster = []
    for j in array_clusters[i]:
        points_cluster.append(points[j])
    route, dist = hami(points_cluster, coord_dict)
    new_cluster = Cluster(route[0], route[-1], route, dist)
    clusters.append(new_cluster)

# min = 1e12
# i_min = -1
# std_deviation = 0

avg_dist, sigma = solver(drivers, pins, dict, x, y, coord_dict, 0, clusters)

min = avg_dist
i_min = 0
std_deviation = sigma

# for k in range(len(drivers)//2):
#     avg_dist, sigma = solver(drivers, pins, dict, x, y, coord_dict, k, clusters)
#     if (avg_dist<min):
#         min = avg_dist
#         i_min = len(drivers)//2 - k
#         std_deviation = sigma


# print("The average length of all the chains:", min)
# print("The proposed solution is obtained with", i_min, "drivers.")
# print("The standard deviation on the length of all the chains:", std_deviation)
# end_time = time.time()
# print("The running time:", (end_time-t0)*1000, ' msec')
