
from functools import cmp_to_key
import matplotlib.pyplot as plt
from random import *
import time


def man_dist(p1, p2):
    return abs(p1[0]-p2[0]) + abs(p1[1]-p2[1])


def hami(points, coord_dict):

    n = len(points)

    indices = range(n)


    def xcompare(left, right):
        if points[left][0] < points[right][0]:
            return -1
        elif points[left][0] == points[right][0] and points[right][1] < points[right][1]:
            return -1
        else:
            return 1


    def ycompare(left, right):
        if points[left][1] < points[right][1]:
            return -1
        elif points[left][1] == points[right][1] and points[right][0] < points[right][0]:
            return -1
        else:
            return 1


    indices_x_sorted = sorted(indices, key=cmp_to_key(xcompare))
    indices_y_sorted = sorted(indices, key=cmp_to_key(ycompare))

    indices_x_sorted.insert(0, -1)
    indices_x_sorted.append(-1)
    indices_y_sorted.insert(0, -1)
    indices_y_sorted.append(-1)


    neighbours_x = [[0, 0]]*n
    neighbours_y = [[0, 0]]*n


    for i in range(1, n+1):
        i0 = indices_x_sorted[i-1]
        i1 = indices_x_sorted[i]
        i2 = indices_x_sorted[i+1]
        neighbours_x[i1] = [i0, i2]


    for i in range(1, n+1):
        i0 = indices_y_sorted[i-1]
        i1 = indices_y_sorted[i]
        i2 = indices_y_sorted[i+1]
        neighbours_y[i1] = [i0, i2]

    # Recorrer usant neighbours
    path = []
    path_length = 0
    visited = [0]*n
    path.append(0)
    visited[0] = 1
    node = 0
    numvis = 1

    # Invariant: xneighbour/yneighbour dona els veins més propers en coordenada x i coordenada y
    while(numvis <= n-1):
        # testeja els quatre veins de cnode
        veins = []

        px = neighbours_x[node][0]
        nx = neighbours_x[node][1]
        py = neighbours_y[node][0]
        ny = neighbours_y[node][1]
        if px != -1 and not visited[px]:
            veins.append(px)
        if nx != -1 and not visited[nx]:
            veins.append(nx)
        if py != -1 and not visited[py]:
            veins.append(py)
        if ny != -1 and not visited[ny]:
            veins.append(ny)
        first = True
        dmin = -1
        closestnode = -1
        # if len(veins) == 0:
        #     print('\n\n PROBLEMAS!!! \n\n')
        for v in veins:
            if first:
                closestnode = v
                dmin = man_dist(points[node], points[v])
                first = False
            elif man_dist(points[node], points[v]) < dmin:
                closestnode = v
                dmin = man_dist(points[node], points[v])
        path.append(closestnode)
        visited[closestnode] = 1
        node = closestnode
        numvis += 1
        path_length += dmin

        if px != -1:
            neighbours_x[px][1] = nx
        if nx != -1:
            neighbours_x[nx][0] = px
        if py != -1:
            neighbours_y[py][1] = ny
        if ny != -1:
            neighbours_y[ny][0] = py

    isthere = [0]*n
    for i in range(n):
        isthere[path[i]] = 1
    worked = 1
    for i in range(n):
        if isthere[i] == 0:
            worked = 0
            break

    # Retornar els nom dels pins connectats
    list_name = []
    for i in range(n):
        list_name.append(coord_dict[points[path[i]]])

    return list_name, path_length
