from dataclasses import dataclass
from typing import List, Tuple
from typing_extensions import TypeAlias

Coord: TypeAlias = Tuple[int, int]   # (x, y)


@dataclass
class Driver:
    name: str
    loc: Coord
    direction: str
    def __hash__(self):
        """S'usa per poder fer comparacions."""
        return id(self)

@dataclass
class Pin:
    name: str
    loc: Coord

# Read drivers

def read_drivers_pins(file_name):

    drivers = []
    pins = []
    dict = {}
    coord_dict = {}
    x_coord = []  # x cordinates of pins
    y_coord = []  # y cordinates of pins

    with open(file_name, "rt") as myFile:
        for line in myFile:
            if (line[0] == '-'):
                ar = line.split(' ')
                driver_name = ar[1]
                driver_type = ar[7]
                #print(driver_name, driver_type)
                line = next(myFile)  # ignore + LAYER CIA
                line = next(myFile)  # take FIX line
                ar = line.split(' ')
                x = int(ar[5])
                y = int(ar[6])
                driver = Driver(driver_name, (int(x), int(y)), driver_type)
                #dict[driver_name] = driver
                drivers.append(driver)

            elif (line[0] == 'i'):
                ar = line.split(' ')
                name = ar[0]
                x = int(ar[5])
                y = int(ar[6])
                pin = Pin(name, (int(x), int(y)))
                dict[name] = pin
                pins.append(pin)
                x_coord.append(int(x))
                y_coord.append(int(y))
                coord_dict[(x, y)] = name

    return drivers, pins, dict, x_coord, y_coord, coord_dict


# Manhattan distance

def distance(loc1: Coord, loc2: Coord) -> float:
    """ Returns the distance in nm between two points.
    Parameters:
    - "loc1: Coord" are the coordinates of one node of a graph
    - "loc2: Coord" are the coordinates of another node of a graph
    """
    return abs(loc1[0] - loc1[0]) + abs(loc1[1] - loc2[1])
