from read_file import *
from kclusters import *
from hami3 import *
import math

@dataclass
class Connection:
    type: str
    from_: Tuple[str,int]
    _to: Tuple[str,int]
    dist: float

@dataclass
class Cluster:
    conn_in: str
    conn_out: str
    route: List[str]
    dist: int

Clusters: TypeAlias = List[Cluster]



def optimizer(sorted_connects: List[Connection], k: int, D_in, D_out, C_in, C_out ):
    #min = []
    connections_dictionary = {}
    check_drivers_inputs = {}
    check_drivers_outputs = {}
    check_cluster_inputs = {}
    check_cluster_outputs = {}

    inputs_used = 0
    outputs_used = 0
    max = len(D_in)-k

    for e in D_in:
        check_drivers_inputs[e.name] = False
    for e in D_out:
        check_drivers_outputs[e.name] = False
    for e in C_in:
        check_cluster_inputs[e[0]] = False
    for e in C_out:
        check_cluster_outputs[e[0]] = False

    i = 0
    while (k>0):
        new = sorted_connects[i]
        if new.type == "C-C":
            if not check_cluster_outputs[new.from_[0]] and not check_cluster_inputs[new._to[0]]:
                check_cluster_outputs[new.from_[0]] = True
                check_cluster_inputs[new._to[0]] = True
                #min.append(new)
                connections_dictionary[new.from_[0]] = [new._to[0], new.dist, new._to[1]]
                k = k-1
        i = i+1


    i = 0
    while(inputs_used != max or outputs_used != max):
        new = sorted_connects[i]
        if new.type == "I-C":
            if inputs_used != max and not check_drivers_inputs[new.from_[0]] and not check_cluster_inputs[new._to[0]]:
                check_drivers_inputs[new.from_[0]] = True
                check_cluster_inputs[new._to[0]] = True
                connections_dictionary[new.from_[0]] = [new._to[0], new.dist, new._to[1]]
                inputs_used = inputs_used+1
        elif new.type == "C-O":
            if outputs_used != max and not check_cluster_outputs[new.from_[0]] and not check_drivers_outputs[new._to[0]]:
                check_cluster_outputs[new.from_[0]] = True
                check_drivers_outputs[new._to[0]] = True
                connections_dictionary[new.from_[0]] = [new._to[0], new.dist, new._to[1]]
                outputs_used = outputs_used+1
        i = i+1

    return connections_dictionary


def print_step(initial: str, last: str)-> None:
    print("- BOGUS NET NAME")
    print("  (", initial, "conn_in )")
    print("  (", last, "conn_out )")
    print(";")

def print_path(clust):
    for p in range(len(clust.route)-1):
        print_step(clust.route[p], clust.route[p+1])


def write_output(clusters, connections_dictionary, Drivers_inputs, dict)-> float:
    total_distance = 0
    list_distances = []
    for chain in Drivers_inputs:
        chain_dist = total_distance
        if chain.name in connections_dictionary:
            ini_name, dist, k_clust = connections_dictionary[chain.name]
            total_distance = total_distance + dist
            print_step(chain.name, ini_name)
            while ini_name in dict:
                print_path(clusters[k_clust])
                end_name = clusters[k_clust].conn_out
                clust_distance = clusters[k_clust].dist
                total_distance = total_distance + clust_distance

                ini_name, dist, k_clust = connections_dictionary[end_name]
                total_distance = total_distance + dist
                print_step(end_name, ini_name)
        chain_dist = total_distance - chain_dist
        list_distances.append(chain_dist)
    return total_distance, list_distances



def standard_deviation(mean:float, list_distances):
    sum = 0
    n = 0
    for value in list_distances:
        if value != 0:
            n = n + 1
            sum = sum + (value-mean)*(value-mean)
    if n == 1:
        return math.sqrt(sum)
    else:
        return math.sqrt(sum/(n-1))


def solver(drivers, pins, dict, x, y, coord_dict, k, clusters):
    Cluster_inputs = []
    Cluster_outputs = []
    Drivers_inputs = []
    Drivers_outputs = []

    for driver in drivers:
        if driver.direction == "INPUT":
            Drivers_inputs.append(driver)
        else:
            Drivers_outputs.append(driver)
    for i in range(len(clusters)):
        Cluster_inputs.append([clusters[i].conn_in, i])
        Cluster_outputs.append([clusters[i].conn_out, i])


    connects = []

    for inp in Drivers_inputs:
        for out in Cluster_inputs:
            new = Connection("I-C", [inp.name, -1], [out[0], out[1]], distance(inp.loc, dict[out[0]].loc))
            connects.append(new)

    for inp in Cluster_outputs:
        for out in Drivers_outputs:
            new = Connection("C-O", [inp[0], inp[1]], [out.name,-1], distance(dict[inp[0]].loc, out.loc))
            connects.append(new)

    for inp in Cluster_outputs:
        for out in Cluster_inputs:
            if (inp[1]!= out[1]):
                new = Connection("C-C", [inp[0], inp[1]], [out[0], out[1]], distance(dict[inp[0]].loc, dict[out[0]].loc))
                connects.append(new)

    sorted_connects = sorted(connects, key = lambda x: x.dist)

    connections_dictionary = optimizer(sorted_connects, k, Drivers_inputs, Drivers_outputs, Cluster_inputs, Cluster_outputs)

    total_distance, list_distances = write_output(clusters, connections_dictionary, Drivers_inputs, dict)
    mean = total_distance/((len(Drivers_inputs)) - k)
    sigma = standard_deviation(mean, list_distances)
    return mean, sigma
