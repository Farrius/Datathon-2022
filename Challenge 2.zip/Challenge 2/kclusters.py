from read_file import *
from pyclustering.cluster.kmeans import kmeans, kmeans_visualizer
from pyclustering.cluster.center_initializer import kmeans_plusplus_initializer
from pyclustering.samples.definitions import FCPS_SAMPLES
from pyclustering.utils import read_sample
from pyclustering.utils.metric import distance_metric, type_metric
import matplotlib.pyplot as plt


def kclustering(drivers, pins, pins_location):

    initial_centers = kmeans_plusplus_initializer(pins_location, len(drivers)//2).initialize()
    # create metric that will be used for clustering
    manhattan_metric = distance_metric(type_metric.MANHATTAN)
    # create instance of K-Means using specific distance metric:
    kmeans_instance = kmeans(pins_location, initial_centers, metric=manhattan_metric)
    # run cluster analysis and obtain results
    kmeans_instance.process()

    clusters = kmeans_instance.get_clusters()
    final_centers = kmeans_instance.get_centers()

    return clusters, final_centers

def visualize_clusters(pins_location, clusters, final_centers):
    # Visualize obtained results
    kmeans_visualizer.show_clusters(pins_location, clusters, final_centers, None, display=True)
    plt.savefig("Klusters.png", format = "PNG")
    #kmeans_visualizer.show_clusters(data, clusters, centers, None, figure=figure, display=False)
